from setuptools import setup

setup(
    name="paquete",
    version="1.0.0",
    description="Este es un paquete de prueba",
    author="Cristobal Salinas",
    author_email="contacto.csalinas@gmail.com",
    url="https://github.com/DeathInWhite",
    scripts=[],
    packages=["paquete","paquete.despedida","paquete.saludo"]
)