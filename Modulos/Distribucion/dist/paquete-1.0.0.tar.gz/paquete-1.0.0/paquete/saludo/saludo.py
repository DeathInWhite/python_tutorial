def saludo():
    print("Saludo desde (paquete/saludo/saludo.py)")