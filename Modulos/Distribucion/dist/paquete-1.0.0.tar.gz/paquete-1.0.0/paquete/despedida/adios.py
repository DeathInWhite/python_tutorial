def despedida():
    print("Despedida desde (paquete/despedida/adios.py)")