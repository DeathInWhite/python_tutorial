def mensaje():
    print("mensaje de prueba de paquete")